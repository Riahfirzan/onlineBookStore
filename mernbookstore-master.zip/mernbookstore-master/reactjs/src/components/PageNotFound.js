import React from "react";

const PageNotFound = (props) => {
  return (
    <div>
      <h1 className="text-centre text-danger">404 Page not found</h1>
    </div>
  );
};

export default PageNotFound;