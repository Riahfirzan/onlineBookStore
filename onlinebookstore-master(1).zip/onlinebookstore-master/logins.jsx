import React, { Component } from 'react';
class Login extends Component {
    state = {}
    render() {
        return (
            <h1>Login page</h1>
        );
    }
}

export default Login;