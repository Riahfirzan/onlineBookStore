import React, { Component } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
const Posters = () => {
    return (
        <div>

        </div>
    );
}

export default Posters;