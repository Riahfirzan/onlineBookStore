import React, { Component } from 'react';
class Home extends Component {
    state = {};
    render() {
        return (
            <h1 className="text-center">Home Page</h1>
        );
    }
}

export default Home;